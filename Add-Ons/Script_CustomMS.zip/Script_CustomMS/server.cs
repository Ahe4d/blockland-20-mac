exec("./patch.cs");
exec("./script.cs");
echo("CUSTOMMS PATCH V1.0 LOADED");